# Make.fun Bounty Submission

## Check the repo ownership file before you build

- Check that the repo contains .makefun/owner.json before you build a fix package or deliver a submission.

- Treat a missing owner file as a package failure and stop the submission until the file is added and committed.

- Verify the file is present in the repo at the exact commit you will submit, not only on your local copy.

- Tell the user plainly when a submission was refused for a missing owner file and name the wasted quota slot so the next attempt is budgeted.

## Check the license before you fix anything

- Open the repo LICENSE file and confirm it carries an SPDX identifier before you build a fix package.

- Add the missing SPDX identifier and commit that change before you submit when the license check fails.

- Treat a license failure as a package failure and stop the submission until the license file is fixed.

## Verify the transcript bundle

- Submit only a verified tar.gz transcript bundle with its sha256 and its repo commit.

- Never send a plain TRANSCRIPT.md file or a summary in place of the session transcript archive.

- Recompute the sha256 of the exact file you will upload and compare it character by character with the sha256 in the package record.

- Check the file size as well as the hash so a tiny wrong file cannot pass as the real bundle.

- Stop and rebuild the bundle when the hash or the size does not match the package record.

## Budget the submission quota before you fix

- Check the daily submission quota and the entry deadline before you spend time on a fix package.

- Treat the Indonesia cap of 3 submissions per UTC day as a hard limit and count the submissions already used that day.

- Stop the fix when the quota is used up and the entry closes before the quota resets.

- Tell the user plainly when a fix package can no longer be submitted because the quota or the deadline has passed.

## Deliver a file the phone can attach

- Mirror the verified tar.gz bundle to a public raw GitHub URL when the phone cannot attach the local file.

- Give the user one link alone in a plain code block with the exact field name it goes into.

- Name the exact file name, size, and sha256 beside the link so the user can spot a wrong download at once.

- Treat a download that saves as a tiny text file as a failed delivery and send a fresh raw link instead of retrying the same link.

## Sign only where the wallet lives

- Complete the final Sign and submit step only on the phone in the Phantom wallet that holds the entry.

- Do not try to sign from the cloud browser because it has no Phantom QR and reports no Solana wallet found.

- Check that the signed in account is the Phantom account that holds the entry before you fill the form.

- Treat a GitHub sign in that opens a different empty account with no entries and no wallet linked as the wrong account and stop there.

- Never import a seed phrase into the cloud browser to work around the missing wallet.

## Available connectors

- Use muse.connector_search to find other connectors and muse.skill_search to find related skills.

- If nothing here fits, look on the web for a maintained API or MCP server and set it up with Custom Connectors and MCPs, or build a custom connector.

## Websites

- Use make.fun for bounty entries and submission status. Carry the repo link, the commit, the verified transcript bundle link with its sha256, and the claim code into the browser task and verify that the entry appears under the correct Phantom account.

## Alternatives for better results

- Ask the user which bounty to fix first when several deadlines compete for the same daily quota.

- Offer to prepare the next fix package while the user signs the current one on the phone.

- Offer to recheck the entry status after the grading window instead of resubmitting the same package.
