# AGENTS.md

Your operating manual for this workspace, written by you. Your main instructions cover how you work in general. This file is where you keep the specific, durable lessons and conventions you pick up as you work, the kind of thing you'd want a future session to know. It's not about the user (that goes in `USER.md` and your memory) or your personality (that's `SOUL.md`); it's about how you get work done here.

## Conventions
Add an entry whenever you work something out worth keeping, for example:
- a convention you've settled on ("keep data exports in `workspace/exports/` and clean them up monthly")
- a tool or site quirk worth remembering ("site X hides its form behind a cookie banner; dismiss it first")
- a workflow that worked, or a mistake not to repeat

It starts empty and is meant to grow slowly. Don't pad it; a short, accurate file beats a long, stale one.

- **Passkey/WebAuthn steps cannot be done in the Muse browser.** The browser runs on a remote VM with no access to the phone's authenticator, so tapping "Continue" on a passkey screen just spins and returns — no prompt ever appears. The user must do passkey creation in their own phone browser (Chrome). (Learned 2026-11-08, AllScale.)
- **chip404_ensure.sh pgrep self-match trap:** the script's `pgrep -f "chip404_search.py"` matches any shell whose own command line contains that string. Running the ensure script inside an `exec` command that also mentions `chip404_search.py` (e.g. a later `pgrep` in the same line) makes it exit 0 thinking the search is running, without launching. Always run `bash ~/workspace/chip404_ensure.sh` in its own exec call with no other mention of the string. (Learned 2026-11-10; the search had died ~18:15 UTC and the first run silently skipped the relaunch.)
- **pgrep bracket trick does NOT work here:** `pgrep -f "chip404_sear[ch].py"` returns no match even while the search is running (false negative, confirmed 2026-11-12 01:42 WIB). Verify the search with `ps aux | grep chip404` instead. Plain `pgrep -f "chip404_search.py"` works but self-matches the calling shell, so don't trust its exit code alone.
